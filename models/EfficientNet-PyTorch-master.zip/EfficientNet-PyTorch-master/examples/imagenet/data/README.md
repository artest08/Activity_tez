### ImageNet

Download ImageNet and place it into `train` and `val` folders here.

More details may be found with the official PyTorch ImageNet example [here](https://github.com/pytorch/examples/blob/master/imagenet). 
